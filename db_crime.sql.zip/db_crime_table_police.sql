
-- --------------------------------------------------------

--
-- Table structure for table `police`
--

CREATE TABLE `police` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `station_name` varchar(100) NOT NULL,
  `email` varchar(70) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `address` varchar(100) NOT NULL,
  `station_id` varchar(50) NOT NULL,
  `crime_type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `police`
--

INSERT INTO `police` (`id`, `name`, `station_name`, `email`, `phone`, `address`, `station_id`, `crime_type`) VALUES
(1111, 'Sharvari Shalgar', 'Wakad Police Station', 'shalgarsharvari@gmail.com', '7058192401', 'Kothrud, Pune.\r\n', 'SY101', 'Rape & Sexual Assault'),
(2222, 'Manish Narkhede', 'Katraj Police Station', 'manishnarkhede@gmail.com', '9175436303', 'ChinchwadGao,Pune', 'SY105', 'Drunk Driving (DUI/DWI)'),
(3333, 'Pritam Sunil Rangari', 'Wakad Police Station', 'pritamrangari125@gmail.com', '8767531150', 'Dange chawk', 'SY101', 'Sexual Harassment'),
(4444, 'Jatin Kose', 'Wakad Police Station', 'jatin@gmail.com', '8010328642', 'Dange chawk, Pune.', 'SY101', 'Phishing & Online Fraud'),
(5555, 'Ganesh Shejul', 'PCMC Police Station', 'shejulganesh@gmail.com', '9021752899', 'Chhatrapati Sambhaji Nagar', 'SY102', 'Lottery & Fake Prize Scams');
