
-- --------------------------------------------------------

--
-- Table structure for table `user_1`
--

CREATE TABLE `user_1` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_1`
--

INSERT INTO `user_1` (`id`, `username`, `password`, `email`, `phone`, `role`) VALUES
(1, 'Amol', '3333', 'amolwahg@gmail.com', '1234567890', 'Admin'),
(2, 'Sandesh', '2222', 'shindesandesh@gmail.com', '9021457863', 'User'),
(3, 'Nirja', '1111', 'pritamrangari125@gmail.com', '8767531150', 'Admin'),
(4, 'Pritam', '1111', 'pritamrangari125@gmail.com', '8767531150', 'User'),
(5, 'Dishant', '1111', 'Thakurdishant@gmail.com', '9561347425', 'User');
