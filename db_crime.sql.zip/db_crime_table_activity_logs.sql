
-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL,
  `activity_type` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `user` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity_logs`
--

INSERT INTO `activity_logs` (`id`, `activity_type`, `description`, `user`, `timestamp`) VALUES
(1, 'police', '<span class=\"font-weight-bold\">New police officer</span> John Smith added to Wakad Police Station', 'admin', '2025-04-19 00:56:38'),
(2, 'fir', '<span class=\"font-weight-bold\">FIR</span> from PCMC Police Station for Phishing & Online Fraud has been <span class=\"font-weight-bold\">Approved</span>', 'admin', '2025-04-18 02:56:38'),
(3, 'criminal', '<span class=\"font-weight-bold\">Criminal record</span> for James Wilson updated with new charges', 'admin', '2025-04-16 02:56:38'),
(4, 'station', '<span class=\"font-weight-bold\">New police station</span> Kharadi Police Station (SY104) added in Maharashtra', 'admin', '2025-04-14 02:56:38'),
(5, 'login', '<span class=\"font-weight-bold\">admin</span> logged in as Admin', 'admin', '2025-04-19 02:26:38'),
(6, 'login', '<span class=\"font-weight-bold\">Amol</span> logged in as Admin', 'Amol', '2025-04-19 06:47:37'),
(7, 'login', '<span class=\"font-weight-bold\">Sandesh</span> logged in as User', 'Sandesh', '2025-04-19 06:47:53'),
(8, 'login', '<span class=\"font-weight-bold\">Ganesh</span> logged in as Police Officer', 'Ganesh', '2025-04-19 06:48:27'),
(9, 'login', '<span class=\"font-weight-bold\">Amol</span> logged in as Admin', 'Amol', '2025-04-19 07:05:30'),
(10, 'login', '<span class=\"font-weight-bold\">Sandesh</span> logged in as User', 'Sandesh', '2025-04-19 07:05:43'),
(11, 'login', '<span class=\"font-weight-bold\">Ganesh</span> logged in as Police Officer', 'Ganesh', '2025-04-19 07:05:57'),
(12, 'police', '<span class=\"font-weight-bold\">New police officer</span> John Smith added to Wakad Police Station', 'admin', '2025-04-20 05:59:12'),
(13, 'fir', '<span class=\"font-weight-bold\">FIR</span> from PCMC Police Station for Phishing & Online Fraud has been <span class=\"font-weight-bold\">Approved</span>', 'admin', '2025-04-19 07:59:12'),
(14, 'criminal', '<span class=\"font-weight-bold\">Criminal record</span> for James Wilson updated with new charges', 'admin', '2025-04-17 07:59:12'),
(15, 'station', '<span class=\"font-weight-bold\">New police station</span> Kharadi Police Station (SY104) added in Maharashtra', 'admin', '2025-04-15 07:59:12'),
(16, 'login', '<span class=\"font-weight-bold\">admin</span> logged in as Admin', 'admin', '2025-04-20 07:29:12'),
(17, 'login', '<span class=\"font-weight-bold\">Amol</span> logged in as Admin', 'Amol', '2025-04-20 11:43:22'),
(18, 'login', '<span class=\"font-weight-bold\">Amol</span> logged in as Admin', 'Amol', '2025-04-20 11:54:28'),
(19, 'fir', '<span class=\"font-weight-bold\">FIR</span> from Wakad Police Station for Sexual Harassment has been <span class=\"font-weight-bold\">Rejected</span>', 'Amol', '2025-04-20 11:56:03'),
(20, 'fir', '<span class=\"font-weight-bold\">FIR</span> from Wakad Police Station for Sexual Harassment has been <span class=\"font-weight-bold\">Approved</span>', 'Amol', '2025-04-20 11:56:32'),
(21, 'login', '<span class=\"font-weight-bold\">Dishant</span> logged in as User', 'Dishant', '2025-04-20 11:58:16'),
(22, 'login', '<span class=\"font-weight-bold\">Ganesh</span> logged in as Police Officer', 'Ganesh', '2025-04-20 12:00:40'),
(23, 'login', '<span class=\"font-weight-bold\">Dishant</span> logged in as User', 'Dishant', '2025-04-20 17:17:35'),
(24, 'login', '<span class=\"font-weight-bold\">Amol</span> logged in as Admin', 'Amol', '2025-04-20 17:17:58'),
(25, 'login', '<span class=\"font-weight-bold\">Amol</span> logged in as Admin', 'Amol', '2025-04-21 03:52:30'),
(26, 'login', '<span class=\"font-weight-bold\">Amol</span> logged in as Admin', 'Amol', '2025-04-21 03:52:30'),
(27, 'login', '<span class=\"font-weight-bold\">Sandesh</span> logged in as User', 'Sandesh', '2025-04-21 03:54:19'),
(28, 'login', '<span class=\"font-weight-bold\">Ganesh</span> logged in as Police Officer', 'Ganesh', '2025-04-21 03:56:59'),
(29, 'login', '<span class=\"font-weight-bold\">Sandesh</span> logged in as User', 'Sandesh', '2025-04-21 03:58:00'),
(30, 'login', '<span class=\"font-weight-bold\">Sandesh</span> logged in as User', 'Sandesh', '2025-04-21 05:53:56'),
(31, 'login', '<span class=\"font-weight-bold\">Sandesh</span> logged in as User', 'Sandesh', '2025-04-21 05:57:53'),
(32, 'login', '<span class=\"font-weight-bold\">Ganesh</span> logged in as Police Officer', 'Ganesh', '2025-04-21 05:59:21'),
(33, 'login', '<span class=\"font-weight-bold\">Amol</span> logged in as Admin', 'Amol', '2025-04-21 06:00:42'),
(34, 'login', '<span class=\"font-weight-bold\">Sandesh</span> logged in as User', 'Sandesh', '2025-04-21 06:40:59'),
(35, 'login', '<span class=\"font-weight-bold\">Ganesh</span> logged in as Police Officer', 'Ganesh', '2025-04-21 06:41:35'),
(36, 'login', '<span class=\"font-weight-bold\">Amol</span> logged in as Admin', 'Amol', '2025-04-21 06:42:44'),
(37, 'login', '<span class=\"font-weight-bold\">Nirja</span> logged in as Admin', 'Nirja', '2025-09-15 16:21:05');
