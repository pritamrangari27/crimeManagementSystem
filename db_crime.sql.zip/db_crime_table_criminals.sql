
-- --------------------------------------------------------

--
-- Table structure for table `criminals`
--

CREATE TABLE `criminals` (
  `station_name` varchar(100) NOT NULL,
  `crime_type` varchar(100) NOT NULL,
  `crime_date` date NOT NULL,
  `crime_time` time NOT NULL,
  `Prison_name` varchar(100) NOT NULL,
  `Court_name` varchar(100) NOT NULL,
  `Criminal_name` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `DateOfBirth` date NOT NULL,
  `email` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `photo` longblob NOT NULL,
  `station_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `criminals`
--

INSERT INTO `criminals` (`station_name`, `crime_type`, `crime_date`, `crime_time`, `Prison_name`, `Court_name`, `Criminal_name`, `contact`, `DateOfBirth`, `email`, `state`, `city`, `address`, `photo`, `station_id`) VALUES
('Wakad Police Station', 'Personal Crime', '2025-03-05', '07:57:00', 'Ganesh Shejul', 'District Court', 'Pritam Rangari', '8767531150', '2025-04-01', 'pritamrangari125@gmail.com', 'Haryana', 'Pune', 'Dange chawk', 0x75706c6f6164732f363764633137656135623835655f696d67312e706e67, 'SY101'),
('Katraj Police Station', 'Cyber Crime', '2025-04-09', '07:20:00', 'Rohit Sharma', 'District Court', 'Travis Head', '8767531150', '1997-03-05', 'SharmaJi@gmail.com', 'Rajasthan', 'Mumbai', 'Sharma Office, Goregaon, Film City. Mumbai.', 0x75706c6f6164732f363830346466393739643862665f726f6869742e6a706567, 'SY105'),
('Khadki Police Station', 'Sexual Assault Crime', '2025-04-23', '19:22:00', 'Virat Kohli', 'Pune High Court', 'Mahendra Singh Dhoni', '9021752890', '2025-04-24', 'kohliVirat@gmail.com', 'Punjab', 'Benguluru', 'Kohli House, High Street Road, Benglore.', 0x75706c6f6164732f363830346530326330636462345f64686f6e692e6a706567, 'SY103');
