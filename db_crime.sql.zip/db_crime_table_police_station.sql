
-- --------------------------------------------------------

--
-- Table structure for table `police_station`
--

CREATE TABLE `police_station` (
  `station_name` varchar(100) NOT NULL,
  `station_id` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `police_station`
--

INSERT INTO `police_station` (`station_name`, `station_id`, `state`, `address`) VALUES
('Wakad Police Station', 'SY101', 'Maharashtra', 'Pune'),
('PCMC Police Station', 'SY102', 'Maharashtra', 'Pune'),
('Khadki Police Station', 'SY103', 'Maharashtra', 'Pune'),
('Kharadi Police Station', 'SY104', 'Madhya Pradesh', 'Baitul\r\n'),
('Katraj Police Station', 'SY105', 'Maharashtra', 'Katrj Chauk,Pune');
