
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `role` varchar(50) NOT NULL,
  `station_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `phone`, `role`, `station_id`) VALUES
(5555, 'Ganesh', '1111', 'ganeshshejul@gmail.com', '8767531150', 'Police', 'SY102'),
(4444, 'Jatin', '1111', 'jatin@gamil.com', '8767531150', 'Police', 'SY101'),
(2222, 'Manish', '1111', 'manish@gmail.com', '1245789865', 'Police', 'SY105'),
(3333, 'Pritam', '1111', 'pritamrangari125@gmail.com', '8767531150', 'Police', 'SY101'),
(1111, 'Sharvari', '1111', 'shalgarsharvari@gmail.com', '1234567890', 'Police', 'SY101');
