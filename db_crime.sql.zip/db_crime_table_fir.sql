
-- --------------------------------------------------------

--
-- Table structure for table `fir`
--

CREATE TABLE `fir` (
  `user_id` int(11) NOT NULL,
  `srNo` int(11) NOT NULL,
  `station_name` varchar(255) NOT NULL,
  `crime_type` varchar(255) NOT NULL,
  `accused` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `number` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `relation` varchar(255) NOT NULL,
  `purpose` text NOT NULL,
  `file` varchar(255) NOT NULL,
  `status` enum('Sent','Approved','Rejected') NOT NULL,
  `station_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fir`
--

INSERT INTO `fir` (`user_id`, `srNo`, `station_name`, `crime_type`, `accused`, `name`, `age`, `number`, `address`, `relation`, `purpose`, `file`, `status`, `station_id`) VALUES
(2, 1, 'Wakad Police Station', 'Sexual Harassment', 'Pritam Sunil Rangari', 'Pritam Sunil Rangari', 42, '0876753115', 'Dange chawk', 'Friend', 'dfb', 'uploads/67e2a94edb36b_img1.png', 'Approved', 'SY101'),
(4, 2, 'Wakad Police Station', 'Rape & Sexual Assault', 'Pritam Sunil Rangari', 'Pritam Sunil Rangari', 42, '0876753115', 'Dange chawk', 'Friend', 'bf', 'uploads/67e2e011e9e85_img1.png', 'Approved', 'SY101'),
(4, 3, 'PCMC Police Station', 'Lottery & Fake Prize Scams', 'Pritam Sunil Rangari', 'Pritam Sunil Rangari', 42, '0876753115', 'Dange chawk', 'Friend', 'an', 'uploads/67e2e54ed7fd5_img1.png', 'Rejected', 'SY102'),
(2, 4, 'Katraj Police Station', 'Drunk Driving (DUI/DWI)', 'Aditya  More', '0', 25, '1234567890', '.', '.', '.', 'uploads/67f2b819f2ac1_wheel.png', 'Approved', 'SY105'),
(5, 5, 'PCMC Police Station', 'Lottery & Fake Prize Scams', 'Parth Bahekar', '0', 19, '9561347425', 'Jalgaon.', 'Dost', 'As mentioned Crime Type', 'uploads/6804e1bd52373_sign1.jpg', 'Approved', 'SY102');
