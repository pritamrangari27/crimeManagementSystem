
-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` int(11) NOT NULL,
  `station_id` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notification_id`, `station_id`, `message`, `created_at`) VALUES
(1, 'SY101', 'New FIR filed: Crime Type - Personal Crime', '2025-03-20 13:10:22'),
(2, 'SY101', 'New FIR filed: Crime Type - Sexual Harassment', '2025-03-20 17:12:34'),
(3, 'SY102', 'New FIR filed: Crime Type - Sexual Harassment', '2025-03-20 17:12:59'),
(4, 'SY103', 'New FIR filed: Crime Type - Kidnapping & Abduction', '2025-03-20 17:13:18'),
(5, 'SY103', 'New FIR filed: Crime Type - Kidnapping & Abduction', '2025-03-20 17:14:03'),
(6, 'SY102', 'New FIR filed: Crime Type - Kidnapping & Abduction', '2025-03-20 17:14:27'),
(7, 'SY102', 'New FIR filed: Crime Type - Kidnapping & Abduction', '2025-03-20 17:14:47'),
(8, 'SY101', 'New FIR filed: Crime Type - Sexual Harassment', '2025-03-20 17:16:44'),
(9, 'SY101', 'New FIR filed: Crime Type - Sexual Harassment', '2025-03-20 17:32:32'),
(10, 'SY101', 'New FIR filed: Crime Type - Rape & Sexual Assault', '2025-03-20 17:33:04'),
(11, 'SY101', 'New FIR filed: Crime Type - Sexual Harassment', '2025-03-24 13:39:54'),
(12, 'SY101', 'New FIR filed: Crime Type - Kidnapping & Abduction', '2025-03-24 15:00:33'),
(13, 'SY101', 'New FIR filed: Crime Type - Sexual Harassment', '2025-03-24 20:18:58'),
(14, 'SY101', 'New FIR filed: Crime Type - Kidnapping & Abduction', '2025-03-25 12:20:45'),
(15, 'SY101', 'New FIR filed: Crime Type - Kidnapping & Abduction', '2025-03-25 12:29:18'),
(16, 'SY101', 'New FIR filed: Crime Type - Sexual Harassment', '2025-03-25 12:29:41'),
(17, 'SY101', 'New FIR filed: Crime Type - Sexual Harassment', '2025-03-25 13:01:07'),
(18, 'SY101', 'New FIR filed: Crime Type - Sexual Harassment', '2025-03-25 13:01:11'),
(19, 'SY101', 'New FIR filed: Crime Type - Sexual Harassment', '2025-03-25 13:02:06'),
(20, 'SY101', 'New FIR filed: Crime Type - Rape & Sexual Assault', '2025-03-25 16:55:46'),
(21, 'SY102', 'New FIR filed: Crime Type - Lottery & Fake Prize Scams', '2025-03-25 17:18:07'),
(22, 'SY105', 'New FIR filed: Crime Type - Drunk Driving (DUI/DWI)', '2025-04-06 17:21:31'),
(23, 'SY102', 'New FIR filed: Crime Type - Lottery & Fake Prize Scams', '2025-04-20 11:59:57');
